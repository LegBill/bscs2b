import java.util.Scanner;
import java.util.ArrayList;
public class AddressBookEntryLegaspi {
    public static void main(String args[])
    {
       
       Database MyData=new Database();
       System.out.println("WELCOME TO DATABASE! Please enter your Name, Address, Telephone Number, and email address");
       Scanner skaner = new Scanner (System.in);
       System.out.print("Name: ");
       MyData.setName(skaner.nextLine());
       System.out.print("Address: ");
       MyData.setAddress(skaner.nextLine());
       System.out.print("Tel. No.: ");
       MyData.setTelephoneNumber(skaner.nextLine());
       System.out.print("email address: ");
       MyData.setEmailAdd(skaner.nextLine());
       System.out.println("***************************************************");
       System.out.println("Here are your Data: ");
       System.out.println("***************************************************");
       System.out.println(MyData.getName());
       System.out.println(MyData.getAddress());
       System.out.println(MyData.getTelephoneNumber());
       System.out.println(MyData.getEmailAdd());
       System.out.println("***************************************************");
    }
}