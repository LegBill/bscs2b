import java.util.Scanner;
import java.util.ArrayList;


public class AddressBookLegaspi {
static Database MyData = new Database();
static ArrayList <String> NameList = new ArrayList<>();
static ArrayList <String> AddressList = new ArrayList<>();
static ArrayList <String> TelephoneNumberList = new ArrayList<>();
static ArrayList <String> EmailAddList = new ArrayList<>();
static int option;
    public static void main (String args[])
    {
       System.out.println("WELCOME TO Bill's DATABASE! What would you like to do today :) ?");
       System.out.println(
       "\t [1] ADD an Entry \n"+
       "\t [2] DELETE an Entry \n"+
       "\t [3] VIEW all Entries \n"+
       "\t [4] EDIT an Entry \n"+
       "\t [5] Leave \n"
       );
       System.out.print("Your Choice: ");
       Scanner skaner = new Scanner (System.in);
       option = skaner.nextInt();
       if (option==1)
       {
           option1(NameList,AddressList,TelephoneNumberList,EmailAddList);
       }
       if (option==2)
       {
           option2(NameList,AddressList,TelephoneNumberList,EmailAddList);
       }
       if (option==3)
       {
          option3();
           
       }
       if (option==4)
       {
           option4();
       }
       if (option==5)
       {
           MyData.leavingAndSayingGoodbye();
       }
    }
    
    public static void option1(ArrayList <String> NameList,ArrayList <String> AddressList,ArrayList <String> TelephoneNumberList,ArrayList <String> EmailAddList)
    {
         System.out.println("Please enter your Name, Address, Telephone Number, and Email Address");
         System.out.print("Name: ");
         Scanner skaner = new Scanner (System.in);
         String temp = skaner.nextLine();
         MyData.setNameInList(temp,NameList);
         System.out.print("Adress: ");
         temp = skaner.nextLine();
         MyData.setAddressInList(temp,AddressList);
         System.out.print("Number: ");
         temp = skaner.nextLine();
         MyData.setTelephoneNumberInList(temp,TelephoneNumberList);
         System.out.print("Email Address: ");
         temp = skaner.nextLine();
         MyData.setEmailAdd(temp,EmailAddList);
         System.out.println("***************************************************");
         System.out.println("THANK YOU SO MUCH! What do you want to do now?");
         System.out.println(
         "\t [1] ADD an Entry \n"+
         "\t [2] Go to Main Menu \n"
         );
         option = skaner.nextInt();
         if (option==1)
         {
             option1(NameList,AddressList,TelephoneNumberList,EmailAddList);
         }
         if (option==2)
         {
             main(null);
         }
    }
    
    public static void option2(ArrayList <String> NameList,ArrayList <String> AddressList,ArrayList <String> TelephoneNumberList,ArrayList <String> EmailAddList)
    {
         System.out.println("Please enter the Name of who you want to delete the entry of");
         Scanner skaner = new Scanner (System.in);
         String temp = skaner.nextLine();
         MyData.deleteEntryInList(temp,NameList,AddressList,TelephoneNumberList,EmailAddList);
         System.out.println("***************************************************");
         System.out.println("THANK YOU SO MUCH! What do you want to do now?");
         System.out.println(
         "\t [1] DELETE an Entry \n"+
         "\t [2] Go to Main Menu \n"
         );
         option = skaner.nextInt();
         if (option==1)
         {
             option2(NameList,AddressList,TelephoneNumberList,EmailAddList);
         }
         if (option==2)
         {
             main(null);
         }
    }
    
    public static void option3()
    {
        for (int i=0;i<=NameList.size()-1;i++)
        {
            System.out.println(NameList.get(i)+"=="+AddressList.get(i)+"=="+TelephoneNumberList.get(i)+"=="+EmailAddList.get(i));
        }
         System.out.println("Press 2 to go back to main menu");
         Scanner skaner=new Scanner(System.in);
         option = skaner.nextInt();
         if (option==2)
         {
            main(null);
         }
    }
    
    public static void option4()
    {
        System.out.println("Type whose data would you like to change?");
        System.out.print("Name: ");
        Scanner skaner = new Scanner(System.in);
        String temp = skaner.nextLine();
        System.out.println("I see, you want to change "+temp+"'s"+" data! Now type the changes in name, address, telephone no., and email add");
        String temp2=temp;
        System.out.print("New Name: ");
        String NewName = skaner.nextLine();
        System.out.print("New Address: ");
        String NewAddress = skaner.nextLine();
        System.out.print("New Telephone Number: ");
        String NewTelephoneNumber = skaner.nextLine();
        System.out.print("New Email Address: ");
        String NewEmailAdd = skaner.nextLine();
        AddressList.set(NameList.indexOf(temp),NewAddress);
        TelephoneNumberList.set(NameList.indexOf(temp),NewTelephoneNumber);
        EmailAddList.set(NameList.indexOf(temp),NewEmailAdd);
        NameList.set(NameList.indexOf(temp),NewName);
        System.out.println("Good! "+temp2+"'s name is now changed with"+NewName+"'s!");
        System.out.println("THANK YOU SO MUCH! What do you want to do now?");
         System.out.println(
         "\t [1] EDIT an Entry \n"+
         "\t [2] Go to Main Menu \n"
         );
         option = skaner.nextInt();
         if (option==1)
         {
             option3();
         }
         if (option==2)
         {
             main(null);
         }
    }
}
