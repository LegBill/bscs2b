import java.util.ArrayList;
public class Database {
String Name;
String Address;
String TelephoneNumber;
String EmailAdd;
/*static ArrayList <String> NameList = new ArrayList<>();
static ArrayList <String> AddressList = new ArrayList<>();
static ArrayList <String> TelephoneNumberList = new ArrayList<>();
static ArrayList <String> EmailAddList = new ArrayList<>();*/
public void setName(String Name)
{
    this.Name=Name;
}

public void setNameInList(String Name, ArrayList <String> NameList)
{
    NameList.add(Name);
}

 

public void setAddress(String Address)
{
    this.Address=Address;
}

public void setAddressInList(String Address, ArrayList <String> AddressList)
{
    AddressList.add(Address);
}

public void setTelephoneNumber(String TelephoneNumber)
{
    this.TelephoneNumber=TelephoneNumber;
}

public void setTelephoneNumberInList(String TelephoneNumber, ArrayList <String> TelephoneNumberList)
{
    TelephoneNumberList.add(TelephoneNumber);
    
}

public void setEmailAdd(String EmailAdd)
{
    this.EmailAdd=EmailAdd;
}

public void setEmailAdd(String EmailAdd, ArrayList <String> EmailAddList)
{
    EmailAddList.add(EmailAdd);
}


public String getName()
{
    return Name;
}

public String getAddress()
{
    return Address;
}

public String getTelephoneNumber()
{
    return TelephoneNumber;
}

public String getEmailAdd()
{
    return EmailAdd;
}

public void deleteEntryInList(String temp,ArrayList <String> NameList,ArrayList <String> AddressList,ArrayList <String> TelephoneNumberList,ArrayList <String> EmailAddList)
{
         AddressList.remove(NameList.indexOf(temp));
         TelephoneNumberList.remove(NameList.indexOf(temp));
         EmailAddList.remove(NameList.indexOf(temp));
         NameList.remove(temp);
}

public void leavingAndSayingGoodbye()
{
    System.out.println("Adios mi amigo! Hasta la proxima vez!");
    System.exit(0);
    
}

}
