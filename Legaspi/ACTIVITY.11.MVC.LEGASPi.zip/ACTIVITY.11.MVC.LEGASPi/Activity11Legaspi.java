
public class Activity11Legaspi {
    public static void main(String [] args)
    {
       AC11View aC11View = new AC11View();
       new AC11Controller(aC11View);
       
    }
}
