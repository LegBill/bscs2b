
public class AC11Model {
    
   //int i;
   //int b;
     /*   public void setTwoNumbers(int i, int b)
        {
            this.i=i;
            this.b=b;
        }*/
        
        public static int getAdditionValue(int i, int b)
        {
            return i+b;
        }
        
         public static int getSubtractionValue(int i, int b)
        {
            return i-b;
        }
        public static int getMultiplicationValue(int i, int b)
        {
            return i*b;
        }
        
        public static double getDivisionValue(double i, double b)
        {
            return i/b;
        }
        public static int getModulusValue(int i, int b)
        {
            return i%b;
        }
    }
    
