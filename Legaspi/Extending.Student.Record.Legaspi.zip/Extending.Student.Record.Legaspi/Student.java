
public class Student {
    String idNumber;
    String studentName;
    String studentAddress;
    String section;
    long cellphoneNumber;
    void studentData( String idNumber, String studentName, String studentAddress, String section, long cellphoneNumber)
    {
       
        this.idNumber = idNumber;
        this.studentName = studentName;
        this.studentAddress = studentAddress;
        this.section = section;
        this.cellphoneNumber = cellphoneNumber;
        
    }
    
    void getStudentData()
    {
        System.out.println("STUDENT'S ID no. : "+idNumber);
        System.out.println("NAME: "+studentName);
        System.out.println("ADDRESS: "+studentAddress);
        System.out.println("SECTION: "+section);
        System.out.println("CELLPHONE no.: "+cellphoneNumber);
        
    }
    
}
