import java.util.*;
public class MainClass {
    public static void main(String[] args)
    {
         BSComputerScience estudiante = new BSComputerScience ();
    
    System.out.println("Hello Computer Science Student! Please enter the following data: ");
    Scanner skaner = new Scanner (System.in);
    System.out.print("ID NUMBER: ");
    String idNumber= skaner.nextLine();
    
    System.out.print("STUDENT'S NAME: ");
    String studentName= skaner.nextLine();
    
    System.out.print("STUDENT'S ADDRESS: ");
    String studentAddress= skaner.nextLine();
    
    System.out.print("STUDENT'S SECTION: ");
    String section= skaner.nextLine();
    
    System.out.print("STUDENT'S CELLPHONE NUMBER: ");
    long cellphoneNumber= skaner.nextLong();
    
    skaner.nextLine();
    
    System.out.print("What are the Langguages you finished studying? : ");
    String langguagesStudied= skaner.nextLine();
    estudiante.setLangguagesStudied(langguagesStudied);
    
    System.out.print("What are the Langguages you are planning to study? : ");
    String langguageToStudy= skaner.nextLine();
    estudiante.setLangguageToStudy(langguageToStudy);
    
    System.out.print("What is your Grade? : ");
    double finalGrade= skaner.nextDouble();
    estudiante.setFinalGrade(finalGrade);
    estudiante.studentData(idNumber,studentName,studentAddress,section,cellphoneNumber);
    
    System.out.println("----------------------------");
    System.out.println("Here are your data: ");
    System.out.println("----------------------------");
    estudiante.getStudentData();
    
    estudiante.getLangguagesStudied();
    estudiante.getLangguageToStudy();
    
    estudiante.remarks();
    }
    
}
