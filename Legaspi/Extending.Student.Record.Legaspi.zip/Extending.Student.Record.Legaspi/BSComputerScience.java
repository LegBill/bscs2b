
public class BSComputerScience extends Student{
   double finalGrade;
   String langguagesStudied;
   String langguageToStudy;
   
   public void setFinalGrade(double finalGrade){
       this.finalGrade = finalGrade;
   }
   
   public void setLangguagesStudied(String langguagesStudied)
   {
       this.langguagesStudied = langguagesStudied;
   }
   
   public void getLangguagesStudied()
   {
       System.out.println("Finished langguage courses: "+langguagesStudied);
   }
    public void setLangguageToStudy(String langguageToStudy)
   {
       this.langguageToStudy = langguageToStudy;
   }
    
     public void getLangguageToStudy()
   {
       System.out.println("Future target language: "+langguageToStudy);
   }
   public void remarks ()
   {
       if(this.finalGrade>=4.0)
       {
           System.out.println("Sorry, your grade is "+finalGrade+". You will enter remedial :( ");
       }
      
       else if(this.finalGrade<=3.59)
       {
           System.out.println("Good! your grade is "+finalGrade+". You are passing!");
       }
       
        else if(this.finalGrade<=2.0)
       {
           System.out.println("Congratulations! your final grade is"+finalGrade+". You are competent in every way!");
       }
   }
   
}
